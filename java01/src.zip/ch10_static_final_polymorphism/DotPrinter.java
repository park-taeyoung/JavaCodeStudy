package ch10_static_final_polymorphism;

public class DotPrinter extends Printer {

	@Override
	public void print() {
		System.out.println("dot ������ �μ�...");
	}
}
