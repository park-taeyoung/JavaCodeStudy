package ch10_static_final_polymorphism;

public class InkjetPrinter extends Printer {
	@Override
	public void print() {
		System.out.println("Inkjet ������ �μ�...");
	}
}
