package ch10_static_final_polymorphism;

public class LaserPrinter extends Printer {
	@Override
	public void print() {
		System.out.println("Laser ������ �μ�...");
	}
}
