package ch10_static_final_polymorphism;

// final class A {
class A {
	private int num;
	public void print() {
		System.out.println(num);
	}
}

class B extends A {
	
}

public class FinalClass {

}



