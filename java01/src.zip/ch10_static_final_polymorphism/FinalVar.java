package ch10_static_final_polymorphism;

public class FinalVar {
	public static void main(String[] args) {
		final int MAX_NUM = 100;
		System.out.println(MAX_NUM);
	}
}



