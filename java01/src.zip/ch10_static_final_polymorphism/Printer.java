package ch10_static_final_polymorphism;

public class Printer {
	public void print() {
		System.out.println("�μ��մϴ�.");
	}
}


