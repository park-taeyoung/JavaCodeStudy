package ch03_operator;

public class Calc {
	public static void main(String[] args) {
		int a = 10;
		int b = 8;
		int c= a / b;
		System.out.println(c);
		c = a % b;
		System.out.println(c);
		
	}
}
