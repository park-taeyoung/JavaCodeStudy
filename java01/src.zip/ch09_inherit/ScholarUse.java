package ch09_inherit;

public class ScholarUse {
	public static void main(String[] args) {
		Scholar s1 = new Scholar();
		s1.input("�豺", "2012001", "�İ�", 1, "1��", 2500000);
		s1.print();
	}
}
